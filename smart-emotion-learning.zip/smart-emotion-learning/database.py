import sqlite3

connection = sqlite3.connect("emotionai.db")

cursor = connection.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS users(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    password TEXT
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS emotions(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    emotion TEXT
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS progress(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    subject TEXT,
    score INTEGER
)
""")

# Default user
cursor.execute("""
INSERT INTO users(username, password)
VALUES('admin', '1234')
""")

connection.commit()

connection.close()

print("Database Created Successfully")