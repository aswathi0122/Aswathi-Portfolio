from deepface import DeepFace
import os
from flask import Flask, render_template, request, redirect, session
import sqlite3

app = Flask(__name__)

app.secret_key = "emotionai"


@app.route("/")
def home():
    return render_template("landing.html")


@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        username = request.form["username"]
        password = request.form["password"]

        connection = sqlite3.connect("emotionai.db")

        cursor = connection.cursor()

        cursor.execute(
            "INSERT INTO users(username, password) VALUES(?, ?)",
            (username, password)
        )

        connection.commit()

        connection.close()

        return redirect("/login")

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        username = request.form["username"]
        password = request.form["password"]

        connection = sqlite3.connect("emotionai.db")

        cursor = connection.cursor()

        cursor.execute(
            "SELECT * FROM users WHERE username=? AND password=?",
            (username, password)
        )

        user = cursor.fetchone()

        connection.close()

        if user:

            session["user"] = username

            return redirect("/dashboard")

        else:
            return "Invalid Username or Password"

    return render_template("login.html")

@app.route("/dashboard")
def dashboard():

    if "user" in session:

        username = session["user"]

        connection = sqlite3.connect("emotionai.db")

        cursor = connection.cursor()

        cursor.execute(
            "SELECT emotion FROM emotions WHERE username=?",
            (username,)
        )

        emotions = cursor.fetchall()

        emotion_list = [emotion[0] for emotion in emotions]

        happy_count = emotion_list.count("happy")
        sad_count = emotion_list.count("sad")
        angry_count = emotion_list.count("angry")

        total_emotions = len(emotion_list)

        cursor.execute(
            "SELECT subject, score FROM progress WHERE username=?",
            (username,)
        )

        progress = cursor.fetchall()

        connection.close()


        return render_template(
            "dashboard.html",
            emotions=emotions,
            progress=progress,
            total_emotions=total_emotions,
            happy_count=happy_count,
            sad_count=sad_count,
            angry_count=angry_count,
            username=username
        )

    return redirect("/login")

@app.route("/emotion", methods=["GET", "POST"])
def emotion():

    if "user" not in session:
        return redirect("/login")

    detected_emotion = None
    image_path = None

    if request.method == "POST":

        file = request.files["image"]

        filepath = os.path.join("uploads", file.filename)

        file.save(filepath)

        image_path = filepath

        try:

            result = DeepFace.analyze(
                img_path=filepath,
                actions=['emotion'],
                enforce_detection=False
            )

            detected_emotion = result[0]['dominant_emotion']

            username = session["user"]

            connection = sqlite3.connect("emotionai.db")

            cursor = connection.cursor()

            cursor.execute(
                "INSERT INTO emotions(username, emotion) VALUES(?, ?)",
                (username, detected_emotion)
            )

            connection.commit()

            connection.close()

        except Exception as e:

            detected_emotion = "Error Detecting Emotion"

    return render_template(
        "emotion.html",
        emotion=detected_emotion,
        image_path=image_path
    )

@app.route("/logout")
def logout():

    session.pop("user", None)

    return redirect("/login")

@app.route("/save_emotion", methods=["POST"])
def save_emotion():

    if "user" in session:

        emotion = request.form["emotion"]

        username = session["user"]

        connection = sqlite3.connect("emotionai.db")

        cursor = connection.cursor()

        cursor.execute(
            "INSERT INTO emotions(username, emotion) VALUES(?, ?)",
            (username, emotion)
        )

        connection.commit()

        connection.close()

        return "Emotion Saved"

    return redirect("/login")

@app.route("/add_progress")
def add_progress():

    if "user" not in session:
        return redirect("/login")

    username = session["user"]

    connection = sqlite3.connect("emotionai.db")

    cursor = connection.cursor()

    sample_data = [
        ("Python", 85),
        ("Machine Learning", 90),
        ("Data Science", 78),
        ("AI", 88)
    ]

    for subject, score in sample_data:

        cursor.execute(
            "INSERT INTO progress(username, subject, score) VALUES(?, ?, ?)",
            (username, subject, score)
        )

    connection.commit()

    connection.close()

    return redirect("/dashboard")

if __name__ == "__main__":
    app.run(debug=True)